package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.ImageButton;
import android.os.Bundle;

public class Tela4_1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela41);

        ImageButton HomeButton4 = (ImageButton) findViewById(R.id.HomeButton4);
        HomeButton4.setOnClickListener(this::homeButton);

        ImageButton ConfigButton = (ImageButton) findViewById(R.id.ConfigButton4);
        ConfigButton.setOnClickListener(this::telaConfigs);

    }

    public void homeButton(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void telaConfigs(View view){
        Intent intent = new Intent(this, Tela5.class);
        startActivity(intent);
    }
}