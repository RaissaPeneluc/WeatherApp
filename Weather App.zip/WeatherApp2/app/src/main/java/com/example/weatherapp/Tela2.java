package com.example.weatherapp;

import android.app.AppComponentFactory;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class Tela2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        ImageButton HomeButton2 = (ImageButton) findViewById(R.id.HomeButton2);
        HomeButton2.setOnClickListener(this::homeButton);

        ImageButton ConfigButton = (ImageButton) findViewById(R.id.ConfigButton2);
        ConfigButton.setOnClickListener(this::telaConfigs);
    }

    public void homeButton(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void telaConfigs(View view){
        Intent intent = new Intent(this, Tela5.class);
        startActivity(intent);
    }
}