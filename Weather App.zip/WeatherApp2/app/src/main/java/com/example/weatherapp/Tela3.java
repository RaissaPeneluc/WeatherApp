package com.example.weatherapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


public class Tela3 extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private RelativeLayout homeRL;
    private ProgressBar loadingPB;
    private TextView cityNameTV, temperatureTV, conditionTV;
    private RecyclerView weatherRV;
    private EditText searchEdt;
    private ImageView backIV, iconIV;
    private ArrayList<WeatherRVModal> weatherRVModalArrayList;
    private WeatherRVAdapter weatherRVAdapter;
    private LocationManager locationManager;
    private int PERMISSION_CODE = 1;
    private String cityName,city;
    private EditText editTextSearch;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);

        setContentView(R.layout.activity_tela3);
        homeRL = findViewById(R.id.idRLHome);
        loadingPB = findViewById(R.id.idPBLoading);
        cityNameTV = findViewById(R.id.idTVCityName);
        temperatureTV = findViewById(R.id.idTVTemperature);
        conditionTV = findViewById(R.id.idTVCondition);
        weatherRV = findViewById(R.id.idRVWeather);
        searchEdt = findViewById(R.id.idEdtTextSearch);
        backIV = findViewById(R.id.idIVBack);
        iconIV = findViewById(R.id.idTVIcon);
        weatherRVModalArrayList = new ArrayList<>();
        weatherRVAdapter = new WeatherRVAdapter(this.weatherRVModalArrayList);
        weatherRV.setAdapter(weatherRVAdapter);
        editTextSearch = findViewById(R.id.idEdtTextSearch);
        Button buttonSearch = (Button) findViewById(R.id.ButtonSearch);

        ImageButton HomeButton3 = (ImageButton) findViewById(R.id.HomeButton3);
        HomeButton3.setOnClickListener(this::homeButton);

        ImageButton ConfigButton = (ImageButton) findViewById(R.id.ConfigButton3);
        ConfigButton.setOnClickListener(this::telaConfigs);

        // Verifica se a permissão de localização foi concedida


        buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });
        //Verificar se a solicitação foi da permição foi concluida
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            // Permissão concedida, podemos obter a localização
            getLocation();
        } else {
            // Solicita permissão de localização se ainda não foi concedida
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private void getLocation() {
        try {
            // Obtém o provedor de localização
            LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

            // Verifica se o provedor de GPS está habilitado
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                // Solicita uma única atualização de localização
                locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, new LocationListener() {
                    @Override
                    public void onLocationChanged(@NonNull Location location) {
                        String city = "";

                        city = editTextSearch.getText().toString();



                        // Localização obtida com sucesso
                        double latitude = location.getLatitude();
                        double longitude = location.getLongitude();

                        String Local =city+"\nLatitude: " + latitude + "\nLongitude: " + longitude;
                        //getCityName(longitude,latitude);
                        cityNameTV.setText(Local);
                        //getWeatherInfo(city);


                        // Faça o que quiser com a latitude e a longitude
                        Log.d("Location", "Latitude: " + latitude);
                        Log.d("Location", "Longitude: " + longitude);

                        // Exemplo: exibir uma mensagem com a latitude e a longitude
                        String message = "Latitude: " + latitude + "\nLongitude: " + longitude;
                        Toast.makeText(Tela3.this, message, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {}

                    @Override
                    public void onProviderEnabled(String provider) {}

                    @Override
                    public void onProviderDisabled(String provider) {}
                }, null);
            } else {
                // GPS não está habilitado, solicite ao usuário para habilitá-lo
                Toast.makeText(this, "Por favor, habilite o GPS", Toast.LENGTH_SHORT).show();
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }



    private void getWeatherInfo(String cityName){
        String url = "http://api.weatherapi.com/v1/forecast.json?key=a109ebf4a0684bb289600551233005&q="+ cityName +"&days=1&aqi=yes&alerts=yes";
        cityNameTV.setText(cityName);
        RequestQueue requestQueue = Volley.newRequestQueue(Tela3.this);


        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                loadingPB.setVisibility(View.GONE);
                homeRL.setVisibility(View.VISIBLE);
                weatherRVModalArrayList.clear();

                try {
                    String temperature = response.getJSONObject("current").getString("temp_c");
                    temperatureTV.setText(temperature + "°C");

                    int isDay = response.getJSONObject("current").getInt("is_day");
                    String condition = response.getJSONObject("current").getJSONObject("condition").getString("text");
                    String conditionIcon = response.getJSONObject("current").getJSONObject("condition").getString("text");
                    Picasso.get().load("http:".concat(conditionIcon)).into(iconIV);
                    conditionTV.setText(condition);

                    if (isDay == 1){
                        //morning
                        Picasso.get().load("https://64.media.tumblr.com/155ce743c11315a15651e2b26832c8a7/tumblr_pxc37j6YUs1y67nt4o1_640.jpg").into(backIV);
                    } else {
                        Picasso.get().load("https://i.pinimg.com/originals/22/8d/11/228d11a9d15437a8214326bc69da239d.jpg").into(backIV);
                    }

                    JSONObject forecastObj = response.getJSONObject("forecast");
                    JSONObject forcast0 = forecastObj.getJSONArray("forecastday").getJSONObject(0);
                    JSONArray hourArray = forcast0.getJSONArray("hour");

                    for (int i=0; i<hourArray.length(); i++){
                        JSONObject hourObj = hourArray.getJSONObject(i);
                        String time = hourObj.getString("time");
                        String temper = hourObj.getString("temp_c");
                        String img = hourObj.getJSONObject("condition").getString("icon");
                        weatherRVModalArrayList.add(new WeatherRVModal(time, temper, img));
                    }

                    weatherRVAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Tela3.this, "Por favor insira um nome de cidade válido...", Toast.LENGTH_SHORT).show();
            }
        });
     }


     private String getCityName (double longitude, double latitude){
        String cityName = "Not found";
         Geocoder gcd = new Geocoder(getBaseContext(), Locale.getDefault());

         try{
             List<Address> addresses = gcd.getFromLocation(latitude, longitude, 10);

             for(Address adr : addresses){
                 if(adr != null){
                     String city = adr.getLocality();

                     if(city != null && city.equals("")){
                         cityName = city;
                     } else {
                         Log.d("TAG", "CITY NOT FOUND");
                         Toast.makeText(this, "User City Not Found...", Toast.LENGTH_SHORT).show();
                     }
                 }
             }

         } catch (IOException e){
             e.printStackTrace();
         }
         return cityName;
     }

    public void homeButton(View view){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    public void telaConfigs(View view){
        Intent intent = new Intent(this, Tela5.class);
        startActivity(intent);
    }


}