// Verifica se a permissão de localização foi concedida

/*import android.annotation.SuppressLint;

import androidx.annotation.NonNull;Atualizar.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
        getLocation();
        }
        });
        //Verificar se a solicitação foi da permição foi concluida
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        == PackageManager.PERMISSION_GRANTED) {
        // Permissão concedida, podemos obter a localização
        getLocation();
        } else {
        // Solicita permissão de localização se ainda não foi concedida
        ActivityCompat.requestPermissions(this,
        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
        LOCATION_PERMISSION_REQUEST_CODE);
        }
        }

private void getLocation() {
        try {
        // Obtém o provedor de localização
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // Verifica se o provedor de GPS está habilitado
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
        // Solicita uma única atualização de localização
        locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, new LocationListener() {
@Override
public void onLocationChanged(@NonNull Location location) {

        // Localização obtida com sucesso
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();

        String Local = dayOfWeek +", "+horario +"\nLatitude: " + latitude + "\nLongitude: " + longitude;
        Latitude.setText(Local);


        // Faça o que quiser com a latitude e a longitude
        Log.d("Location", "Latitude: " + latitude);
        Log.d("Location", "Longitude: " + longitude);

        // Exemplo: exibir uma mensagem com a latitude e a longitude
        String message = "Latitude: " + latitude + "\nLongitude: " + longitude;
        Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
        }

@Override
public void onStatusChanged(String provider, int status, Bundle extras) {}

@Override
public void onProviderEnabled(String provider) {}

@Override
public void onProviderDisabled(String provider) {}
        }, null);
        } else {
        // GPS não está habilitado, solicite ao usuário para habilitá-lo
        Toast.makeText(this, "Por favor, habilite o GPS", Toast.LENGTH_SHORT).show();
        }
        } catch (SecurityException e) {
        e.printStackTrace();
        }
        }

@SuppressLint("MissingSuperCall")
@Override
public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
        // Permissão concedida, podemos obter a localização
        getLocation();
        } else {
        // Permissão negada pelo usuário
        Toast.makeText(this, "Permissão de localização negada", Toast.LENGTH_SHORT).show();
        }
        }
        }



        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
        ActivityCompat.requestPermissions(Tela3.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, PERMISSION_CODE);
        }

        Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
        cityName = getCityName(location.getLongitude(), location.getLatitude());
        getWeatherInfo(cityName);


        EditText editTextSearch = (EditText) findViewById(R.id.idEdtTextSearch);
        Button buttonSearch = (Button) findViewById(R.id.ButtonSearch);

        ImageButton HomeButton3 = (ImageButton) findViewById(R.id.HomeButton3);
        HomeButton3.setOnClickListener(this::homeButton);

        ImageButton ConfigButton = (ImageButton) findViewById(R.id.ConfigButton3);
        ConfigButton.setOnClickListener(this::telaConfigs);

        buttonSearch.setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View v) {
        String city = editTextSearch.getText().toString();



        if(city.isEmpty()){
        Toast.makeText(Tela3.this, "Please enter city", Toast.LENGTH_SHORT).show();
        } else {
        cityNameTV.setText(cityName);
        getWeatherInfo(city);
        }
        }
        })*/