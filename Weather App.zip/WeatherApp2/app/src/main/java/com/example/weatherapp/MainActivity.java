package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button MyLoc = (Button) findViewById(R.id.MyLoc);
        MyLoc.setOnClickListener(this::telaLocalizacao);

        Button SearchLoc = (Button) findViewById(R.id.SearchLoc);
        SearchLoc.setOnClickListener(this::telaPesquisa);

        Button LocSalvos = (Button) findViewById(R.id.LocSalvos);
        LocSalvos.setOnClickListener(this::telaLocSalvos);

        ImageButton ConfigButton = (ImageButton) findViewById(R.id.ConfigButton);
        ConfigButton.setOnClickListener(this::telaConfigs);

    }

    public void telaLocalizacao(View view){
        Intent intent = new Intent(this, Tela2.class);
        startActivity(intent);
    }

    public void telaPesquisa(View view){
        Intent intent = new Intent (this, Tela3.class);
        startActivity(intent);
    }

    public void telaLocSalvos(View view){
        Intent intent = new Intent (this, Tela4_1.class);
        startActivity(intent);
    }

    public void telaConfigs(View view){
        Intent intent = new Intent(this, Tela5.class);
        startActivity(intent);
    }




}

